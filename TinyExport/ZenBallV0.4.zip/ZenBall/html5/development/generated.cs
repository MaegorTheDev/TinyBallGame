﻿using UTiny;
using UTiny.Core2D;
using UTiny.Math;
using UTiny.Shared;
using UTiny.HTML;
using UTiny.Rendering;
using UTiny.Physics2D;
using UTiny.Text;
using UTiny.UILayout;
using ut.EditorExtensions;
using ut;
using UTiny.HitBox2D;
using UTiny.Audio;
using UTiny.Animation;

/*
 * !!! TEMP UNITL PROPER SCENE FORMAT !!!
 */
namespace entities.game
{
    namespace Scene
    {
        public struct Component : IComponentData
        {
        }
    }
    namespace Coin
    {
        public struct Component : IComponentData
        {
        }
    }
    namespace Obstacle
    {
        public struct Component : IComponentData
        {
        }
    }
    namespace ShotPeg
    {
        public struct Component : IComponentData
        {
        }
    }
}

namespace game
{
    public struct ArrowTag : IComponentData
    {
    }
    public struct Ball : IComponentData
    {
        public float MaxPower;
        public float Power;
        public bool Shoot;
        public Vector2 MoveDirection;
        public int DeltaDirection;
    }
    public struct Borders : IComponentData
    {
        public float Height;
        public float Width;
        public float WorldHeight;
        public float WorldWidth;
    }
    public struct Coin : IComponentData
    {
    }
    public struct HitAudio : IComponentData
    {
        public DynamicArray<Entity> HitAudioClips;
    }
    public struct HitSound : IComponentData
    {
    }
    public struct InputHelper : IComponentData
    {
        public game.InputType InputType;
        public Vector2 FirstTouchData;
        public bool IsClickDown;
    }
    public struct NoShotsSprite : IComponentData
    {
        public Entity DefaultSprite;
        public Entity NoShots;
    }
    public struct Object : IComponentData
    {
    }
    public struct Obstacle : IComponentData
    {
    }
    public struct ObstacleSpawnerHelper : IComponentData
    {
        public float AreaPercentage;
        public Vector2 XScaleValues;
        public Vector2 YScaleValues;
        public float BorderOffset;
        public game.ObstacleSpawnerMode SpawnMode;
    }
    public struct ShotPeg : IComponentData
    {
        public Entity InitialSprite;
        public Entity CurrentSprite;
        public Entity UsedSprite;
    }
    public struct Wall : IComponentData
    {
    }
    public enum GameState
    {
        Waiting = 0
        , Playing = 1
        , Aiming = 2
    }
    public enum InputType
    {
        Direction = 0
        , Power = 1
    }
    public enum ObstacleSpawnerMode
    {
        Random = 0
        , Json = 1
    }
}

namespace ut.Core2D
{
    namespace layers
    {
        public struct Default : IComponentData
        {
        }
        public struct TransparentFX : IComponentData
        {
        }
        public struct IgnoreRaycast : IComponentData
        {
        }
        public struct Water : IComponentData
        {
        }
        public struct UI : IComponentData
        {
        }
        public struct PostProcessing : IComponentData
        {
        }
    }
}

namespace ut.Math
{
}

namespace ut
{
}

namespace ut.Shared
{
}

namespace ut.Core2D
{
}

namespace ut.HTML
{
}

namespace ut.Rendering
{
}

namespace ut.Rendering
{
}

namespace ut.HTML
{
}

namespace ut.Core2D
{
}

namespace ut.Rendering
{
}

namespace ut.Rendering
{
}

namespace ut.Physics2D
{
}

namespace ut.Core2D
{
}

namespace ut.Text
{
}

namespace ut.HTML
{
}

namespace ut.UILayout
{
}

namespace ut.EditorExtensions
{
    public struct AssetReferenceAnimationClip : IComponentData
    {
        public string guid;
        public long fileId;
        public int type;
    }
    public struct AssetReferenceAudioClip : IComponentData
    {
        public string guid;
        public long fileId;
        public int type;
    }
    public struct AssetReferenceSprite : IComponentData
    {
        public string guid;
        public long fileId;
        public int type;
    }
    public struct AssetReferenceSpriteAtlas : IComponentData
    {
        public string guid;
        public long fileId;
        public int type;
    }
    public struct AssetReferenceTexture2D : IComponentData
    {
        public string guid;
        public long fileId;
        public int type;
    }
    public struct AssetReferenceTile : IComponentData
    {
        public string guid;
        public long fileId;
        public int type;
    }
    public struct AssetReferenceTMP_FontAsset : IComponentData
    {
        public string guid;
        public long fileId;
        public int type;
    }
    public struct CameraCullingMask : IComponentData
    {
        public int mask;
    }
    public struct EntityLayer : IComponentData
    {
        public int layer;
    }
}

namespace ut
{
}

namespace ut.HitBox2D
{
}

namespace ut.Audio
{
}

namespace ut.Animation
{
}
namespace game
{
    public struct DirectionalArrowBehaviour_State : IComponentData
    {
        public bool initialized;
        public bool enabled;
        public bool onEnableCalled;
        public bool onDisableCalled;
    }
}
namespace game
{
    public class BallShootingSystemJS : IComponentSystem
    {
    }
}
namespace game
{
    public class BorderSystemJS : IComponentSystem
    {
    }
}
namespace game
{
    public class CoinSpawnSystemJS : IComponentSystem
    {
    }
}
namespace game
{
    [UpdateBefore(typeof(UTiny.Shared.UserCodeEnd))]
    [UpdateAfter(typeof(UTiny.Shared.UserCodeStart))]
    public class CollisionAudioSystemJS : IComponentSystem
    {
    }
}
namespace game
{
    public class GameSystemJS : IComponentSystem
    {
    }
}
namespace game
{
    public class JsonObstacleSpawnerJS : IComponentSystem
    {
    }
}
namespace game
{
    public class LineRenderingSystemJS : IComponentSystem
    {
    }
}
namespace game
{
    public class ObstacleSpawnSystemJS : IComponentSystem
    {
    }
}
namespace game
{
    public class ShotsUISystemJS : IComponentSystem
    {
    }
}
namespace game
{
    public class TimeLethalitySystemJS : IComponentSystem
    {
    }
}
namespace game
{
    public class DirectionInputSystemJS : IComponentSystem
    {
    }
}
namespace game
{
    public class DirectionalPowerSystemJS : IComponentSystem
    {
    }
}
namespace game
{
    public class PotencyDirectionalSystemJS : IComponentSystem
    {
    }
}
namespace game
{
    public class PotencyInputSystemJS : IComponentSystem
    {
    }
}
