var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var game;
(function (game) {
    //@ut.executeAfter(ut.Shared.UserCodeStart)
    //@ut.executeBefore(ut.Shared.UserCodeEnd)
    /** New System */
    var BallShootingSystem = /** @class */ (function (_super) {
        __extends(BallShootingSystem, _super);
        function BallShootingSystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        BallShootingSystem.prototype.OnUpdate = function () {
            var _this = this;
            var ballEntity = this.world.getEntityByName("Ball");
            this.world.usingComponentData(ballEntity, [ut.Entity, game.Ball, game.InputHelper, ut.Physics2D.Velocity2D], function (entity, ball, inputHelper, velocity) {
                if (game.GameSystem.CurrentGameMode != game.GameState.Aiming) {
                    return;
                }
                if (inputHelper.IsClickDown) {
                    if (BallShootingSystem.lastVelocity.x == 0 && BallShootingSystem.lastVelocity.y == 0) {
                        BallShootingSystem.lastVelocity = velocity.velocity;
                    }
                    var setVelocity = new ut.Physics2D.SetVelocity2D;
                    setVelocity.velocity = new Vector2(0, 0);
                    if (_this.world.hasComponent(ballEntity, ut.Physics2D.SetVelocity2D))
                        _this.world.setComponentData(ballEntity, setVelocity);
                    else
                        _this.world.addComponentData(ballEntity, setVelocity);
                }
                else if (ball.Shoot && game.GameSystem.currentPlays > 0) {
                    var setVelocity = new ut.Physics2D.SetVelocity2D;
                    setVelocity.velocity = new Vector2(ball.MoveDirection.x * ball.MaxPower, ball.MoveDirection.y * ball.MaxPower);
                    if (_this.world.hasComponent(ballEntity, ut.Physics2D.SetVelocity2D))
                        _this.world.setComponentData(ballEntity, setVelocity);
                    else
                        _this.world.addComponentData(ballEntity, setVelocity);
                    ball.Power = 0;
                    ball.MoveDirection = new Vector2(0, 0);
                    ball.Shoot = false;
                    game.GameSystem.Play();
                    game.GameSystem.CurrentGameMode = game.GameState.Playing;
                    BallShootingSystem.lastVelocity = new Vector2(0, 0);
                }
                else {
                    var setVelocity = new ut.Physics2D.SetVelocity2D;
                    setVelocity.velocity = BallShootingSystem.lastVelocity;
                    if (_this.world.hasComponent(ballEntity, ut.Physics2D.SetVelocity2D))
                        _this.world.setComponentData(ballEntity, setVelocity);
                    else
                        _this.world.addComponentData(ballEntity, setVelocity);
                    ball.Power = 0;
                    ball.MoveDirection = new Vector2(0, 0);
                    ball.Shoot = false;
                    game.GameSystem.CurrentGameMode = game.GameState.Playing;
                    BallShootingSystem.lastVelocity = new Vector2(0, 0);
                }
                /**
    
                let division = ball.MaxPower / 5;
    
                        if(division > ball.Power){
                            renderer.color = new ut.Core2D.Color(0, 0, 0, 1);
                        }
                        else if(division * 2 > ball.Power){
                            renderer.color = new ut.Core2D.Color(0, 50/255, 255/255, 1);
                        }
                        else if(division * 3 > ball.Power){
                            renderer.color = new ut.Core2D.Color(0, 1, 0, 1);
                        }
                        else if(division * 4 > ball.Power){
                            renderer.color = new ut.Core2D.Color(1, 1, 0, 1);
                        }
                        else {
                            renderer.color = new ut.Core2D.Color(1, 0, 0, 1);
                        }
                */
            });
        };
        BallShootingSystem.lastVelocity = new Vector2(0, 0);
        return BallShootingSystem;
    }(ut.ComponentSystem));
    game.BallShootingSystem = BallShootingSystem;
})(game || (game = {}));
var game;
(function (game) {
    /** New System */
    var BorderSystem = /** @class */ (function (_super) {
        __extends(BorderSystem, _super);
        function BorderSystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        BorderSystem.prototype.OnUpdate = function () {
            var _this = this;
            var display = this.world.getConfigData(ut.Core2D.DisplayInfo);
            var camera = this.world.getEntityByName("Camera");
            var borders = this.world.getEntityByName("Borders");
            var background = this.world.getEntityByName("Background");
            var halfSize = this.world.getComponentData(camera, ut.Core2D.Camera2D).halfVerticalSize;
            /**

            this.world.usingComponentData(borders, [game.Borders],
                (borders)=>{
                   if(display.frameWidth != borders.Width){
                       BorderSystem.calculateOnce = true;
                   }
            });
            */
            if (BorderSystem.calculateOnce) {
                var height_1;
                var width_1;
                var worldHeight_1;
                var worldWidth_1;
                //CalculateSize
                this.world.usingComponentData(borders, [game.Borders], function (borders) {
                    height_1 = borders.Height = display.frameHeight;
                    width_1 = borders.Width = display.frameWidth;
                    worldHeight_1 = borders.WorldHeight = (halfSize * 2) - 8;
                    if (display.frameHeight < display.frameWidth) {
                        worldWidth_1 = borders.WorldWidth = (halfSize * 2 * 0.35) * 2;
                    }
                    else {
                        worldWidth_1 = borders.WorldWidth = ((halfSize * width_1) / height_1) * 2;
                    }
                });
                //Set borders
                var index_1 = 0;
                this.world.forEach([game.Wall, ut.Core2D.TransformLocalPosition], function (wall, transform) {
                    if (index_1 == 0) {
                        transform.position = new Vector3(-worldWidth_1 / 2 - 0.5, 0);
                    }
                    else if (index_1 == 1) {
                        transform.position = new Vector3(worldWidth_1 / 2 + 0.5, 0);
                    }
                    else {
                        return;
                    }
                    index_1++;
                    _this.world.usingComponentData(background, [ut.Core2D.TransformLocalScale], function (scale) {
                        scale.scale = new Vector3(worldWidth_1, (halfSize * 2));
                    });
                });
                game.ShotsUISystem.Initialize(this.world);
                game.GameSystem.spawnObstacles = true;
                BorderSystem.calculateOnce = false;
            }
        };
        BorderSystem.calculateOnce = true;
        return BorderSystem;
    }(ut.ComponentSystem));
    game.BorderSystem = BorderSystem;
})(game || (game = {}));
var game;
(function (game) {
    /** New System */
    var CoinSpawnSystem = /** @class */ (function (_super) {
        __extends(CoinSpawnSystem, _super);
        function CoinSpawnSystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        CoinSpawnSystem.prototype.OnUpdate = function () {
            var _this = this;
            var height;
            var width;
            var borders = this.world.getEntityByName("Borders");
            this.world.usingComponentData(borders, [game.Borders], function (borders) {
                height = borders.WorldHeight;
                width = borders.WorldWidth;
            });
            //Spawning Coins
            if (game.GameSystem.spawnCoins) {
                CoinSpawnSystem.maxCoins = game.GameSystem.randomIntFromInterval(CoinSpawnSystem.randomInterval.x, CoinSpawnSystem.randomInterval.y);
                CoinSpawnSystem.actualCoins = 0;
                CoinSpawnSystem.spawnedCoins = 0;
                for (var i = 0; i < CoinSpawnSystem.maxCoins; i++) {
                    if (i % 4 == 0) {
                        CoinSpawnSystem.spawnCoins(this.world, "game.Coin", 0, width / 2 - 3, 0, height / 2 - 5);
                    }
                    else if (i % 4 == 1) {
                        CoinSpawnSystem.spawnCoins(this.world, "game.Coin", 0, width / 2 - 3, -height / 2 + 3, 0);
                    }
                    else if (i % 4 == 2) {
                        CoinSpawnSystem.spawnCoins(this.world, "game.Coin", -width / 2 + 3, 0, 0, height / 2 - 5);
                    }
                    else if (i % 4 == 3) {
                        CoinSpawnSystem.spawnCoins(this.world, "game.Coin", -width / 2 + 3, 0, -height / 2 + 3, 0);
                    }
                    else if (i % 4 == 4) {
                        CoinSpawnSystem.spawnCoins(this.world, "game.Coin", -width / 4 + 2, width / 4 - 2, -height / 4 + 2, height / 4 - 2);
                    }
                }
                game.GameSystem.spawnCoins = false;
            }
            //Check if the coins have hits. 
            this.world.forEach([ut.Entity, ut.HitBox2D.HitBoxOverlapResults, game.Coin], function (entity, hitboxoverlapresults, coin) {
                for (var i = 0; i < hitboxoverlapresults.overlaps.length; i++) {
                    var otherEntity = hitboxoverlapresults.overlaps[i].otherEntity;
                    if (!_this.world.exists(otherEntity) || _this.world.hasComponent(otherEntity, game.Ball)) {
                        if (_this.world.exists(entity) && _this.world.hasComponent(entity, ut.Core2D.TransformLocalPosition)) {
                            ut.Core2D.TransformService.destroyTree(_this.world, entity);
                            game.TimeLethalitySystem.ResetTimer();
                            game.CollisionAudioSystem.PlayCoinSound(_this.world);
                            CoinSpawnSystem.actualCoins++;
                        }
                    }
                }
            });
            //NewLevel
            if (CoinSpawnSystem.actualCoins >= CoinSpawnSystem.spawnedCoins) {
                game.GameSystem.NewLevel(this.world);
            }
        };
        CoinSpawnSystem.spawnCoins = function (world, entityGroup, minX, maxX, minY, maxY) {
            var findLocation = false;
            var index = 0;
            var randomPos;
            var _loop_1 = function () {
                randomPos = new Vector3(game.GameSystem.randomIntFromInterval(minX, maxX), game.GameSystem.randomIntFromInterval(minY, maxY));
                var coinInside = false;
                world.forEach([game.Obstacle, ut.Core2D.TransformLocalPosition, ut.Core2D.TransformLocalScale], function (obstacle, transform, scale) {
                    if (transform.position.x - scale.scale.x / 2 < randomPos.x &&
                        transform.position.x + scale.scale.x / 2 > randomPos.x ||
                        transform.position.y - scale.scale.y / 2 < randomPos.y &&
                            transform.position.y + scale.scale.y / 2 > randomPos.y) {
                        coinInside = true;
                    }
                });
                world.forEach([game.Coin, ut.Core2D.TransformLocalPosition], function (coin, transform) {
                    var deltaX = transform.position.x - randomPos.x;
                    var deltaY = transform.position.y - randomPos.y;
                    var magnitude = deltaX * deltaX + deltaY * deltaY;
                    if (magnitude < 100) {
                        coinInside = true;
                    }
                });
                if (!coinInside) {
                    findLocation = true;
                }
                index++;
            };
            while (!findLocation && index < 250) {
                _loop_1();
            }
            var coin;
            if (findLocation) {
                coin = ut.EntityGroup.instantiate(world, entityGroup)[0];
                world.usingComponentData(coin, [ut.Core2D.TransformLocalPosition], function (transformLocalPosition) {
                    transformLocalPosition.position = randomPos;
                });
                CoinSpawnSystem.spawnedCoins++;
            }
            return coin;
        };
        CoinSpawnSystem.increaseRandomInterval = function () {
            var current = CoinSpawnSystem.randomInterval;
            CoinSpawnSystem.randomInterval = new Vector2(current.x + 1, current.y + 1);
        };
        CoinSpawnSystem.resetRandomInterval = function () {
            CoinSpawnSystem.randomInterval = new Vector2(3, 5);
        };
        CoinSpawnSystem.maxCoins = 5;
        CoinSpawnSystem.actualCoins = 0;
        CoinSpawnSystem.spawnedCoins = 0;
        CoinSpawnSystem.randomInterval = new Vector2(3, 5);
        return CoinSpawnSystem;
    }(ut.ComponentSystem));
    game.CoinSpawnSystem = CoinSpawnSystem;
})(game || (game = {}));
var game;
(function (game) {
    var CollisionAudioSystem = /** @class */ (function (_super) {
        __extends(CollisionAudioSystem, _super);
        function CollisionAudioSystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        CollisionAudioSystem.prototype.OnUpdate = function () {
            var _this = this;
            var hitAudioObject = this.world.getEntityByName("HitObject");
            this.world.forEach([ut.Entity, ut.Physics2D.ColliderContacts, game.Ball], function (entity, collidercontacts) {
                if (collidercontacts.contacts.length == 0) {
                    return;
                }
                for (var i = 0; i < collidercontacts.contacts.length; i++) {
                    var otherEntity = collidercontacts.contacts[i];
                    if (!_this.world.exists(otherEntity)) {
                        continue;
                    }
                    if (_this.world.hasComponent(otherEntity, game.HitSound)) {
                        _this.world.usingComponentData(hitAudioObject, [ut.Entity, game.HitAudio, ut.Audio.AudioSource], function (entity, hitAudio, audiosource) {
                            var randomAudioClip = hitAudio.HitAudioClips[game.GameSystem.randomIntFromInterval(0, hitAudio.HitAudioClips.length - 1)];
                            audiosource.clip = randomAudioClip;
                            if (!_this.world.hasComponent(entity, ut.Audio.AudioSourceStart)) {
                                _this.world.addComponent(entity, ut.Audio.AudioSourceStart);
                            }
                        });
                        return;
                    }
                }
            });
        };
        CollisionAudioSystem.PlayCoinSound = function (world) {
            var coinAudioObject = world.getEntityByName("CoinAudio");
            world.usingComponentData(coinAudioObject, [ut.Entity, ut.Audio.AudioSource], function (entity, audiosource) {
                if (!world.hasComponent(entity, ut.Audio.AudioSourceStart)) {
                    world.addComponent(entity, ut.Audio.AudioSourceStart);
                }
            });
        };
        CollisionAudioSystem = __decorate([
            ut.executeAfter(ut.Shared.UserCodeStart),
            ut.executeBefore(ut.Shared.UserCodeEnd),
            ut.requiredComponents(ut.Physics2D.ColliderContacts),
            ut.requiredComponents(ut.Core2D.Sprite2DRenderer)
        ], CollisionAudioSystem);
        return CollisionAudioSystem;
    }(ut.ComponentSystem));
    game.CollisionAudioSystem = CollisionAudioSystem;
})(game || (game = {}));
var game;
(function (game) {
    /** New System */
    var GameSystem = /** @class */ (function (_super) {
        __extends(GameSystem, _super);
        function GameSystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        GameSystem.prototype.OnUpdate = function () {
        };
        GameSystem.Play = function () {
            if (GameSystem.currentPlays != 0)
                this.currentPlays--;
        };
        GameSystem.RestartWorld = function (world) {
            ut.EntityGroup.destroyAll(world, 'game.Coin');
            ut.EntityGroup.destroyAll(world, 'game.Obstacle');
            var ball = world.getEntityByName("Ball");
            world.usingComponentData(ball, [ut.Entity, game.Ball, ut.Core2D.TransformLocalPosition, ut.Core2D.Sprite2DRendererOptions], function (entity, ball, position, renderer) {
                var setVelocity = new ut.Physics2D.SetVelocity2D;
                setVelocity.velocity = new Vector2(0, 0);
                if (world.hasComponent(entity, ut.Physics2D.SetVelocity2D))
                    world.setComponentData(entity, setVelocity);
                else
                    world.addComponentData(entity, setVelocity);
                ball.Power = 0;
                ball.MoveDirection = new Vector2(0, 0);
                ball.Shoot = false;
                position.position = new Vector3(0, 0);
                renderer.size = new Vector2(1, 1);
            });
            game.CoinSpawnSystem.resetRandomInterval();
            GameSystem.currentPlays = GameSystem.playsPerLevel + 2;
            GameSystem.spawnObstacles = true;
            GameSystem.CurrentGameMode = game.GameState.Waiting;
        };
        GameSystem.NewLevel = function (world) {
            ut.EntityGroup.destroyAll(world, 'game.Coin');
            ut.EntityGroup.destroyAll(world, 'game.Obstacle');
            if (GameSystem.BallRadius == 0) {
                var ball = world.getEntityByName("Ball");
                world.usingComponentData(ball, [game.Ball, ut.Core2D.TransformLocalScale], function (ball, scale) {
                    GameSystem.BallRadius = scale.scale.x / 2;
                });
            }
            game.CoinSpawnSystem.increaseRandomInterval();
            GameSystem.currentPlays += GameSystem.playsPerLevel;
            if (GameSystem.currentPlays > GameSystem.MaxPlays) {
                GameSystem.currentPlays = GameSystem.MaxPlays;
            }
            GameSystem.spawnObstacles = true;
        };
        GameSystem.randomIntFromInterval = function (min, max) {
            return Math.floor(Math.random() * (max - min + 1) + min);
        };
        GameSystem.BallRadius = 0;
        GameSystem.spawnObstacles = false;
        GameSystem.MaxPlays = 3;
        //TODO Might Change
        GameSystem.playsPerLevel = 1;
        GameSystem.currentPlays = 3;
        return GameSystem;
    }(ut.ComponentSystem));
    game.GameSystem = GameSystem;
})(game || (game = {}));
var game;
(function (game) {
    /** New System */
    var LineRenderingSystem = /** @class */ (function (_super) {
        __extends(LineRenderingSystem, _super);
        function LineRenderingSystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        LineRenderingSystem.prototype.OnUpdate = function () {
            var line = this.world.getEntityByName("Guideline");
            if (!ut.Core2D.Input.isTouchSupported()) {
                var mousePos = ut.Core2D.Input.getInputPosition();
                if (ut.Runtime.Input.getMouseButton(0)) {
                    this.ProcessOnPressed(line, mousePos);
                }
                else if (ut.Runtime.Input.getMouseButtonUp(0)) {
                    this.ProcessFinishInput(line);
                }
            }
            else {
                if (ut.Core2D.Input.touchCount() > 0) {
                    var touch = ut.Core2D.Input.getTouch(0);
                    if (touch.phase == ut.Core2D.TouchState.Moved) {
                        this.ProcessOnPressed(line, new Vector2(touch.x, touch.y));
                        //console.log("moved: " + ut.Core2D.Input.touchCount());
                    }
                    else if (touch.phase == ut.Core2D.TouchState.Ended) {
                        this.ProcessFinishInput(line);
                    }
                }
            }
        };
        LineRenderingSystem.prototype.ProcessOnPressed = function (entity, touchPosition) {
            var _this = this;
            var ball = this.world.getEntityByName("Ball");
            var coordinates = this.ScreenToWorldCoordenates(touchPosition);
            var linePosition;
            var lineRotation;
            var lineMagnitude;
            this.world.usingComponentData(ball, [ut.Core2D.TransformLocalPosition], function (position) {
                var diference = new Vector2(coordinates.x - position.position.x, coordinates.y - position.position.y);
                lineMagnitude = Math.sqrt(diference.x * diference.x + diference.y * diference.y);
                var normalized = diference.normalize();
                lineRotation = Math.atan2(normalized.y, normalized.x);
                var radiusOffset = normalized.multiplyScalar(game.GameSystem.BallRadius);
                linePosition = new Vector3(position.position.x + radiusOffset.x, position.position.y + radiusOffset.y);
            });
            this.world.usingComponentData(entity, [ut.Core2D.TransformLocalPosition, ut.Core2D.TransformLocalRotation, ut.Core2D.Sprite2DRenderer, ut.Core2D.Sprite2DRendererOptions], function (position, rotation, renderer, options) {
                renderer.color = new ut.Core2D.Color(1, 1, 1, 1);
                var sprite = _this.world.getComponentData(renderer.sprite, ut.Core2D.Sprite2D);
                sprite.pivot = new Vector2(0, 0.5);
                _this.world.setComponentData(renderer.sprite, sprite);
                position.position = linePosition;
                rotation.rotation.setFromAxisAngle(new Vector3(0, 0, 1), lineRotation);
                options.size = new Vector2(lineMagnitude - (game.GameSystem.BallRadius * 2), 0.25);
            });
            var dotedBall = this.world.getEntityByName("DottedGuide");
            this.world.usingComponentData(dotedBall, [ut.Core2D.TransformLocalPosition, ut.Core2D.Sprite2DRenderer], function (position, renderer) {
                renderer.color = new ut.Core2D.Color(1, 1, 1, 1);
                position.position = new Vector3(coordinates.x, coordinates.y);
            });
        };
        LineRenderingSystem.prototype.ProcessFinishInput = function (entity) {
            this.world.usingComponentData(entity, [ut.Core2D.Sprite2DRenderer], function (renderer) {
                renderer.color = new ut.Core2D.Color(1, 1, 1, 0);
            });
            var dotedBall = this.world.getEntityByName("DottedGuide");
            this.world.usingComponentData(dotedBall, [ut.Core2D.Sprite2DRenderer], function (renderer) {
                renderer.color = new ut.Core2D.Color(1, 1, 1, 0);
            });
        };
        LineRenderingSystem.prototype.ScreenToWorldCoordenates = function (screenPos) {
            var position = screenPos;
            var camera = this.world.getEntityByName("Camera");
            var display = this.world.getConfigData(ut.Core2D.DisplayInfo);
            var halfSize = this.world.getComponentData(camera, ut.Core2D.Camera2D).halfVerticalSize;
            position.x -= display.frameWidth / 2;
            position.y -= display.frameHeight / 2;
            //Mouse world position
            var worldPos = new Vector3(position.x / (display.frameWidth / 2) * (display.frameWidth / display.frameHeight * halfSize), position.y / (display.frameHeight / 2) * halfSize);
            return worldPos;
        };
        return LineRenderingSystem;
    }(ut.ComponentSystem));
    game.LineRenderingSystem = LineRenderingSystem;
})(game || (game = {}));
var game;
(function (game) {
    /** New System */
    var ObstacleSpawnSystem = /** @class */ (function (_super) {
        __extends(ObstacleSpawnSystem, _super);
        function ObstacleSpawnSystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ObstacleSpawnSystem.prototype.OnUpdate = function () {
            if (game.GameSystem.spawnObstacles) {
                var objectSpawner = this.world.getEntityByName("Spawners");
                var areaPercerntage_1;
                var XValues_1;
                var YValues_1;
                var borderOffset_1;
                var borders = this.world.getEntityByName("Borders");
                this.world.usingComponentData(borders, [game.Borders], function (borders) {
                    ObstacleSpawnSystem.totalArea = borders.WorldHeight * borders.WorldWidth;
                });
                this.world.usingComponentData(objectSpawner, [game.ObstacleSpawnerHelper], function (helper) {
                    areaPercerntage_1 = helper.AreaPercentage;
                    XValues_1 = helper.XScaleValues;
                    YValues_1 = helper.YScaleValues;
                    borderOffset_1 = helper.BorderOffset;
                });
                var obstacleArea = ObstacleSpawnSystem.totalArea * areaPercerntage_1;
                var currentArea = 0;
                var index = 0;
                while (currentArea < obstacleArea && index < 100) {
                    var randomScaleX = game.GameSystem.randomIntFromInterval(XValues_1.x, XValues_1.y);
                    var randomScaleY = game.GameSystem.randomIntFromInterval(YValues_1.x, YValues_1.y);
                    var currentObstacleArea = randomScaleX * randomScaleY;
                    if (currentObstacleArea + currentArea < obstacleArea) {
                        if (ObstacleSpawnSystem.spawnObstacle(this.world, "game.Obstacle", randomScaleX, randomScaleY, borderOffset_1, borders)) {
                            currentArea += currentObstacleArea;
                        }
                    }
                    index++;
                }
                game.GameSystem.spawnCoins = true;
                game.GameSystem.spawnObstacles = false;
            }
        };
        ObstacleSpawnSystem.spawnObstacle = function (world, entityGroup, xScale, yScale, offset, borders) {
            var randomPos;
            var halfWidth;
            var halfHeigth;
            world.usingComponentData(borders, [game.Borders], function (borders) {
                halfWidth = borders.WorldWidth / 2;
                halfHeigth = borders.WorldHeight / 2;
            });
            var findLocation = false;
            var index = 0;
            var _loop_2 = function () {
                randomPos = new Vector3(game.GameSystem.randomIntFromInterval((-halfWidth + offset) + xScale / 2, (halfWidth - offset) - xScale / 2), game.GameSystem.randomIntFromInterval((-halfHeigth + offset) + yScale / 2, (halfHeigth - offset) - yScale / 2));
                var coinInside = false;
                world.forEach([game.Object, ut.Core2D.TransformLocalPosition, ut.Core2D.TransformLocalScale], function (obstacle, transform, scale) {
                    if ((transform.position.x - scale.scale.x / 2 - offset < randomPos.x - xScale / 2 &&
                        transform.position.x + scale.scale.x / 2 + offset > randomPos.x + xScale / 2) || (transform.position.y - scale.scale.y / 2 - offset < randomPos.y - yScale / 2 &&
                        transform.position.y + scale.scale.y / 2 + offset > randomPos.y + yScale / 2) &&
                        (Math.abs(transform.position.y - randomPos.y) > yScale && Math.abs(transform.position.x - randomPos.x) > xScale)) {
                        coinInside = true;
                    }
                });
                var player = world.getEntityByName("Ball");
                if (player != null) {
                    world.usingComponentData(player, [ut.Core2D.TransformLocalPosition], function (localBallPosition) {
                        if (localBallPosition != null) {
                            if (randomPos.x - xScale / 2 < localBallPosition.position.x - 2 && randomPos.x + xScale / 2 > localBallPosition.position.x + 2 ||
                                randomPos.y - yScale / 2 < localBallPosition.position.y - 2 && randomPos.y + yScale / 2 > localBallPosition.position.y + 2) {
                                coinInside = true;
                            }
                        }
                    });
                }
                if (!coinInside) {
                    findLocation = true;
                }
                index++;
            };
            while (!findLocation && index < 250) {
                _loop_2();
            }
            var obstacle;
            if (findLocation) {
                obstacle = ut.EntityGroup.instantiate(world, entityGroup)[0];
                world.usingComponentData(obstacle, [ut.Core2D.TransformLocalPosition, ut.Core2D.TransformLocalScale], function (positionObstacle, obstacleScale) {
                    positionObstacle.position = randomPos;
                    obstacleScale.scale = new Vector3(xScale, yScale);
                });
            }
            return findLocation;
        };
        ObstacleSpawnSystem.totalArea = (38 * 50);
        return ObstacleSpawnSystem;
    }(ut.ComponentSystem));
    game.ObstacleSpawnSystem = ObstacleSpawnSystem;
})(game || (game = {}));
var game;
(function (game) {
    var ShotsUISystem = /** @class */ (function (_super) {
        __extends(ShotsUISystem, _super);
        /** New System */
        function ShotsUISystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ShotsUISystem_1 = ShotsUISystem;
        ShotsUISystem.prototype.OnUpdate = function () {
            if (!ShotsUISystem_1.initialized) {
                return;
            }
            var index = 1;
            var currentPlays = game.GameSystem.currentPlays;
            var isClickDown = false;
            this.world.forEach([game.Ball, game.InputHelper, ut.Entity], function (ball, helper, entity) {
                isClickDown = helper.IsClickDown;
            });
            if (isClickDown && currentPlays == 0) {
                ShotsUISystem_1.frameCount++;
                if (ShotsUISystem_1.frameCount % 14 == 0) {
                    this.world.forEach([game.NoShotsSprite, ut.Core2D.Sprite2DRenderer], function (peg, renderer) {
                        renderer.sprite = peg.NoShots;
                    });
                }
                else if (ShotsUISystem_1.frameCount % 14 == 7) {
                    this.world.forEach([game.NoShotsSprite, ut.Core2D.Sprite2DRenderer], function (peg, renderer) {
                        renderer.sprite = peg.DefaultSprite;
                    });
                }
            }
            else {
                ShotsUISystem_1.frameCount = 0;
                this.world.forEach([game.ShotPeg, ut.Core2D.Sprite2DRenderer], function (peg, renderer) {
                    if (index < currentPlays) {
                        renderer.sprite = peg.InitialSprite;
                    }
                    else if (index == currentPlays) {
                        if (isClickDown) {
                            renderer.sprite = peg.CurrentSprite;
                        }
                        else {
                            renderer.sprite = peg.InitialSprite;
                        }
                    }
                    else {
                        renderer.sprite = peg.UsedSprite;
                    }
                    index++;
                });
            }
        };
        ShotsUISystem.Initialize = function (world) {
            ShotsUISystem_1.initialized = true;
            var borders = world.getEntityByName("Borders");
            var numberOfShots = game.GameSystem.MaxPlays;
            world.usingComponentData(borders, [game.Borders], function (borders) {
                var pegSize = ((borders.WorldWidth - ((numberOfShots - 1) * 0.75)) - 5) / numberOfShots;
                var pegYPos = (borders.WorldHeight / 2) - 0.5;
                var currentX = ((-borders.WorldWidth / 2) + pegSize / 2) + 2.5;
                for (var i = 0; i < numberOfShots; i++) {
                    var peg = ut.EntityGroup.instantiate(world, "game.ShotPeg")[0];
                    world.usingComponentData(peg, [ut.Core2D.TransformLocalPosition, ut.Core2D.Sprite2DRendererOptions], function (transformLocalPosition, options) {
                        var pos = new Vector3(currentX, pegYPos);
                        transformLocalPosition.position = pos;
                        var scale = new Vector2(pegSize, 3);
                        options.size = scale;
                    });
                    currentX += pegSize + 0.75;
                }
                ShotsUISystem_1.initialized = true;
            });
        };
        ShotsUISystem.coroutine_ChangeSprites = function (world) {
            /**
            return setTimeout(() =>
            {
                if(isTouchDown){
                if(this.countBlinks % 2 == 0){
                    world.forEach([game.NoShotsSprite, ut.Core2D.Sprite2DRenderer],
                        (peg, renderer) => {
                        renderer.sprite = peg.NoShots;
                    });
                } else {
                    world.forEach([game.NoShotsSprite, ut.Core2D.Sprite2DRenderer],
                        (peg, renderer) => {
                        renderer.sprite = peg.DefaultSprite;
                    });
                }
                ShotsUISystem.countBlinks ++;
                }

            }, 100);
            */
        };
        var ShotsUISystem_1;
        ShotsUISystem.initialized = false;
        ShotsUISystem.animationActive = false;
        ShotsUISystem.frameCount = 0;
        ShotsUISystem = ShotsUISystem_1 = __decorate([
            ut.executeBefore(game.BallShootingSystem)
            /** New System */
        ], ShotsUISystem);
        return ShotsUISystem;
    }(ut.ComponentSystem));
    game.ShotsUISystem = ShotsUISystem;
})(game || (game = {}));
var game;
(function (game) {
    /** New System */
    var TimeLethalitySystem = /** @class */ (function (_super) {
        __extends(TimeLethalitySystem, _super);
        function TimeLethalitySystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TimeLethalitySystem.prototype.OnUpdate = function () {
            var _this = this;
            if (game.GameSystem.CurrentGameMode != game.GameState.Playing) {
                return;
            }
            var dt = this.scheduler.deltaTime();
            TimeLethalitySystem.CurrentTime += dt;
            //console.log(TimeLethalitySystem.CurrentTime );
            if (TimeLethalitySystem.CurrentTime > TimeLethalitySystem.TimeToGetNextCoin) {
                game.GameSystem.RestartWorld(this.world);
                TimeLethalitySystem.CurrentTime = 0;
                var loseGameSound = this.world.getEntityByName("Lose");
                this.world.usingComponentData(loseGameSound, [ut.Entity, ut.Audio.AudioSource], function (entity) {
                    if (!_this.world.hasComponent(entity, ut.Audio.AudioSourceStart)) {
                        _this.world.addComponent(entity, ut.Audio.AudioSourceStart);
                    }
                });
                this.world.forEach([ut.Entity, game.Ball, ut.Core2D.Sprite2DSequencePlayer], function (entity, ball, player) {
                    player.paused = true;
                    player.time = 0;
                });
            }
            else {
                if (TimeLethalitySystem.TimeToGetNextCoin - TimeLethalitySystem.CurrentTime < TimeLethalitySystem.TimeToStartBlinking) {
                    this.world.forEach([ut.Entity, game.Ball, ut.Core2D.Sprite2DSequencePlayer], function (entity, ball, player) {
                        player.paused = false;
                        var percentage = (TimeLethalitySystem.TimeToGetNextCoin - TimeLethalitySystem.CurrentTime) / 3;
                        player.speed = 7 * (1 - percentage);
                    });
                }
                else {
                    this.world.forEach([ut.Entity, game.Ball, ut.Core2D.Sprite2DSequencePlayer], function (entity, ball, player) {
                        player.paused = true;
                        player.time = 0;
                    });
                }
                /**
                    this.world.forEach([ut.Entity, game.Ball, ut.Core2D.Sprite2DRendererOptions], (entity, ball, renderer ) => {
                        //Change the sprite size!
                    let ratio =  (1-(TimeLethalitySystem.CurrentTime/ TimeLethalitySystem.TimeToGetNextCoin)) + 0.4;
                    if(ratio > 1){
                        ratio = 1;
                    }

                    renderer.size = new Vector2 (ratio, ratio);
                });*/
            }
        };
        TimeLethalitySystem.ResetTimer = function () {
            TimeLethalitySystem.CurrentTime = 0;
        };
        TimeLethalitySystem.TimeToGetNextCoin = 8;
        TimeLethalitySystem.TimeToStartBlinking = 3;
        TimeLethalitySystem.CurrentTime = 0;
        return TimeLethalitySystem;
    }(ut.ComponentSystem));
    game.TimeLethalitySystem = TimeLethalitySystem;
})(game || (game = {}));
var game;
(function (game) {
    //@ut.executeAfter(ut.Shared.UserCodeStart)
    //@ut.executeBefore(ut.Shared.UserCodeEnd)
    /** InputHandlingSystem */
    var DirectionInputSystem = /** @class */ (function (_super) {
        __extends(DirectionInputSystem, _super);
        function DirectionInputSystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        DirectionInputSystem.prototype.OnUpdate = function () {
            var _this = this;
            var display = this.world.getConfigData(ut.Core2D.DisplayInfo);
            var camera = this.world.getEntityByName("Camera");
            var cameraPos = this.world.getComponentData(camera, ut.Core2D.TransformLocalPosition).position;
            var halfSize = this.world.getComponentData(camera, ut.Core2D.Camera2D).halfVerticalSize;
            this.world.forEach([ut.Entity, game.Ball, ut.Physics2D.Velocity2D, ut.Core2D.TransformLocalPosition, game.InputHelper], function (entity, ball, velocity, localPosition, inputHelper) {
                if (inputHelper.InputType == game.InputType.Power) {
                    return;
                }
                if (!ut.Core2D.Input.isTouchSupported()) {
                    if (ut.Runtime.Input.getMouseButton(0)) {
                        _this.ProcessStartInput(entity, velocity, inputHelper);
                    }
                    else if (ut.Runtime.Input.getMouseButtonUp(0)) {
                        var mousePos = ut.Core2D.Input.getInputPosition();
                        // adjust 0,0 to the center of the screen
                        mousePos.x -= display.frameWidth / 2;
                        mousePos.y -= display.frameHeight / 2;
                        //Mouse world position
                        var mouseWorldPos = new Vector2(cameraPos.x + mousePos.x / (display.frameWidth / 2) * (display.frameWidth / display.frameHeight * halfSize), cameraPos.y + mousePos.y / (display.frameHeight / 2) * halfSize);
                        _this.ProcessFinishInput(mouseWorldPos, ball, localPosition, inputHelper);
                    }
                }
                else {
                    if (ut.Core2D.Input.touchCount() > 0) {
                        var touch = ut.Core2D.Input.getTouch(0);
                        if (touch.phase == ut.Core2D.TouchState.Began) {
                            //console.log("began: " + ut.Core2D.Input.touchCount());							
                            _this.ProcessStartInput(entity, velocity, inputHelper);
                        }
                        else if (touch.phase == ut.Core2D.TouchState.Ended) {
                            var pos = new Vector2(touch.x, touch.y);
                            pos.x -= display.frameWidth / 2;
                            pos.y -= display.frameHeight / 2;
                            //Mouse world position
                            var mouseWorldPos = new Vector2(cameraPos.x + pos.x / (display.frameWidth / 2) * (display.frameWidth / display.frameHeight * halfSize), cameraPos.y + pos.y / (display.frameHeight / 2) * halfSize);
                            _this.ProcessFinishInput(mouseWorldPos, ball, localPosition, inputHelper);
                        }
                    }
                }
            });
        };
        DirectionInputSystem.prototype.ProcessStartInput = function (entity, velocity, inputHelper) {
            inputHelper.IsClickDown = true;
            game.GameSystem.CurrentGameMode = game.GameState.Aiming;
            //console.log("StartInput");			
        };
        DirectionInputSystem.prototype.ProcessFinishInput = function (worldPosition, ball, localPosition, inputHelper) {
            var playerWorldPosition = localPosition.position;
            var diference = new Vector2(worldPosition.x - playerWorldPosition.x, worldPosition.y - playerWorldPosition.y);
            var magnitude = Math.sqrt(diference.x * diference.x + diference.y * diference.y);
            var normalized = new Vector2(diference.x / magnitude, diference.y / magnitude);
            inputHelper.IsClickDown = false;
            ball.MoveDirection = normalized;
            ball.Shoot = true;
        };
        return DirectionInputSystem;
    }(ut.ComponentSystem));
    game.DirectionInputSystem = DirectionInputSystem;
})(game || (game = {}));
/**
 * 		this.ProcessTouchInput(localPosition, speed.speed * dt);
 * 		ProcessTouchInput(position: Vector3, speed):void
        {
            if (ut.Core2D.Input.isTouchSupported()) {
                if (ut.Core2D.Input.touchCount() > 0) {
                    let touch: ut.Core2D.Touch = ut.Core2D.Input.getTouch(0);
                    let player = this.world.getEntityByName("Player");
                    let playerWorldPos = ut.Core2D.TransformService.computeWorldPosition(this.world, player);
                    let transPos = ut.Core2D.TransformService.worldToWindow(this.world, this.world.getEntityByName("Camera"), playerWorldPos, new Vector2(600,800));

                    if (touch.x >= transPos.x){
                        position.x += speed;
                    }
                    else if (touch.x < transPos.x){
                        position.x -= speed;
                    }
                    if (touch.y >= transPos.y){
                        position.y += speed;
                    }
                    else if (touch.y < transPos.y){
                        position.y -= speed;
                    }

                    if (touch.phase == ut.Core2D.TouchState.Moved) {
                        //console.log("moved: " + ut.Core2D.Input.touchCount());
                    }
                    else if (touch.phase == ut.Core2D.TouchState.Ended) {
                        //console.log("ended: " + ut.Core2D.Input.touchCount());
                    }
                    else if (touch.phase == ut.Core2D.TouchState.Stationary) {
                        //console.log("holding: " + ut.Core2D.Input.touchCount());
                    }
                    else if (touch.phase == ut.Core2D.TouchState.Canceled) {
                        //console.log("cancelled: " + ut.Core2D.Input.touchCount());
                    }
                    else if (touch.phase == ut.Core2D.TouchState.Began) {
                        //console.log("began: " + ut.Core2D.Input.touchCount());
                    }
                    else {
                        console.log("NO TOUCH STATE!!!");
                    }
                }
            }
            else {
                //console.log("TOUCH IS DISABLED!!!");
            }
        }
 *
 */ 
var game;
(function (game) {
    //@ut.executeAfter(ut.Shared.UserCodeStart)
    //@ut.executeBefore(ut.Shared.UserCodeEnd)
    /** New System */
    var DirectionalPowerSystem = /** @class */ (function (_super) {
        __extends(DirectionalPowerSystem, _super);
        function DirectionalPowerSystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        DirectionalPowerSystem.prototype.OnUpdate = function () {
            /**
            this.world.forEach([game.Ball, game.InputHelper], (ball, inputHelper) => {
                
                const powerDelta = ball.MaxPower / 100;
                if(inputHelper.InputType == game.InputType.Power){
                    return;
                }

                if(inputHelper.IsClickDown){
                    ball.Power = 0;
                    let currentPower = ball.Power;
                    if(currentPower <= ball.MaxPower && currentPower >= 0){
                        ball.Power = currentPower + (powerDelta * ball.DeltaDirection);
                    } else {
                        if(currentPower <= 0){
                            ball.DeltaDirection = 1;
                            ball.Power = 0;
                        }
                        else {
                            ball.DeltaDirection = -1;
                            ball.Power = ball.MaxPower;
                        }
                    }

                                                       
                }
            }); */
        };
        return DirectionalPowerSystem;
    }(ut.ComponentSystem));
    game.DirectionalPowerSystem = DirectionalPowerSystem;
})(game || (game = {}));
0;
var game;
(function (game) {
    var DirectionalArrowBehaviourFilter = /** @class */ (function (_super) {
        __extends(DirectionalArrowBehaviourFilter, _super);
        function DirectionalArrowBehaviourFilter() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return DirectionalArrowBehaviourFilter;
    }(ut.EntityFilter));
    game.DirectionalArrowBehaviourFilter = DirectionalArrowBehaviourFilter;
    var DirectionalArrowBehaviour = /** @class */ (function (_super) {
        __extends(DirectionalArrowBehaviour, _super);
        function DirectionalArrowBehaviour() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return DirectionalArrowBehaviour;
    }(ut.ComponentBehaviour));
    game.DirectionalArrowBehaviour = DirectionalArrowBehaviour;
})(game || (game = {}));
var game;
(function (game) {
    /** New System */
    var PotencyDirectionalSystem = /** @class */ (function (_super) {
        __extends(PotencyDirectionalSystem, _super);
        function PotencyDirectionalSystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PotencyDirectionalSystem.prototype.OnUpdate = function () {
            //Nothing
        };
        return PotencyDirectionalSystem;
    }(ut.ComponentSystem));
    game.PotencyDirectionalSystem = PotencyDirectionalSystem;
})(game || (game = {}));
/** DEPRECATED
 *   export class PotencyDirectionalSystem extends ut.ComponentSystem {
        static currentAngle = 0;
        OnUpdate():void {
            
            const angleLimit = 360;
            const angleDelta = 0.1;
            const arrow = this.world.getEntityByName("Arrow");
            
            //let renderer = this.world.getComponentData(arrow, ut.Core2D.Sprite2DRenderer);
            //let position = this.world.getComponentData(arrow, ut.Core2D.TransformLocalPosition);
            //let rotation = this.world.getComponentData(arrow, ut.Core2D.TransformLocalRotation);


            this.world.forEach([ut.Entity, game.Ball, ut.Physics2D.Velocity2D, ut.Core2D.TransformLocalPosition, game.InputHelper], (entity, ball, velocity, localPosition , inputHelper ) => {
                if(inputHelper.InputType == game.InputType.Direction){
                    return;
                }
                
                if(inputHelper.IsClickDown){
                    PotencyDirectionalSystem.currentAngle += angleDelta;

                    if(PotencyDirectionalSystem.currentAngle == angleLimit){
                        PotencyDirectionalSystem.currentAngle = 0;
                    }
                    let direction = new Vector2(Math.cos(PotencyDirectionalSystem.currentAngle), Math.sin(PotencyDirectionalSystem.currentAngle));
                    
                    ball.MoveDirection = direction;
                    
                    this.world.usingComponentData(arrow, [ut.Core2D.Sprite2DRenderer, ut.Core2D.TransformLocalPosition, ut.Core2D.TransformLocalRotation, game.ArrowTag],
                        (renderer, position, rotation) => {
                            renderer.color = new ut.Core2D.Color(0, 0, 0, 1);
                            position.position = localPosition.position;
                            rotation.rotation = new Quaternion().setFromEuler(new Euler(0, 0, PotencyDirectionalSystem.currentAngle));
                    });
                           

                }
                else {
                    this.world.usingComponentData(arrow, [ut.Core2D.Sprite2DRenderer, game.ArrowTag],
                        (renderer) => {
                            renderer.color = new ut.Core2D.Color(0, 0, 0, 0);
                    });
                }
            });
        }
    }
 *
 *
 *
 */
var game;
(function (game) {
    //@ut.executeAfter(ut.Shared.UserCodeStart)
    //@ut.executeBefore(ut.Shared.UserCodeEnd)
    /** New System */
    var PotencyInputSystem = /** @class */ (function (_super) {
        __extends(PotencyInputSystem, _super);
        function PotencyInputSystem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PotencyInputSystem.prototype.OnUpdate = function () {
            var _this = this;
            var display = this.world.getConfigData(ut.Core2D.DisplayInfo);
            this.world.forEach([ut.Entity, game.Ball, ut.Physics2D.Velocity2D, game.InputHelper, ut.Core2D.TransformLocalPosition], function (entity, ball, velocity, inputHelper, localPosition) {
                if (inputHelper.InputType == game.InputType.Direction) {
                    return;
                }
                if (!ut.Core2D.Input.isTouchSupported()) {
                    var mousePos = ut.Core2D.Input.getInputPosition();
                    if (ut.Runtime.Input.getMouseButtonDown(0)) {
                        _this.ProcessStartInput(entity, velocity, mousePos, inputHelper);
                    }
                    else if (ut.Runtime.Input.getMouseButton(0)) {
                        _this.ProcessOnPressed(mousePos, inputHelper, localPosition.position);
                    }
                    else if (ut.Runtime.Input.getMouseButtonUp(0)) {
                        _this.ProcessFinishInput(ball, mousePos, inputHelper);
                    }
                }
                else {
                    if (ut.Core2D.Input.touchCount() > 0) {
                        var touch = ut.Core2D.Input.getTouch(0);
                        if (touch.phase == ut.Core2D.TouchState.Began) {
                            //console.log("began: " + ut.Core2D.Input.touchCount());	
                            _this.ProcessStartInput(entity, velocity, new Vector2(touch.x, touch.y), inputHelper);
                        }
                        else if (touch.phase == ut.Core2D.TouchState.Moved) {
                            _this.ProcessOnPressed(new Vector2(touch.x, touch.y), inputHelper, localPosition.position);
                            //console.log("moved: " + ut.Core2D.Input.touchCount());
                        }
                        else if (touch.phase == ut.Core2D.TouchState.Ended) {
                            _this.ProcessFinishInput(ball, new Vector2(touch.x, touch.y), inputHelper);
                        }
                    }
                }
            });
        };
        PotencyInputSystem.prototype.ProcessStartInput = function (entity, velocity, firstTouchData, inputHelper) {
            var setVelocity = new ut.Physics2D.SetVelocity2D;
            setVelocity.velocity = new Vector2(0, 0);
            if (this.world.hasComponent(entity, ut.Physics2D.SetVelocity2D))
                this.world.setComponentData(entity, setVelocity);
            else
                this.world.addComponentData(entity, setVelocity);
            inputHelper.IsClickDown = true;
            //GameSystem.CurrentGameMode = GameState.Waiting;                
            inputHelper.FirstTouchData = firstTouchData;
        };
        PotencyInputSystem.prototype.ProcessOnPressed = function (touchData, inputHelper, ballPosition) {
            var diference = new Vector2(touchData.x - inputHelper.FirstTouchData.x, touchData.y - inputHelper.FirstTouchData.y);
            var normalized = diference.normalize().multiplyScalar(-1);
            var arrow = this.world.getEntityByName("Arrow");
            this.world.usingComponentData(arrow, [ut.Core2D.Sprite2DRenderer, ut.Core2D.TransformLocalPosition, ut.Core2D.TransformLocalRotation, game.ArrowTag], function (renderer, position, rotation) {
                renderer.color = new ut.Core2D.Color(1, 1, 1, 1);
                position.position = ballPosition;
                //console.log(angleDeg);
                rotation.rotation.setFromAxisAngle(new Vector3(0, 0, 1), Math.atan2(normalized.y, normalized.x));
            });
        };
        PotencyInputSystem.prototype.ProcessFinishInput = function (ball, touchData, inputHelper) {
            var arrow = this.world.getEntityByName("Arrow");
            this.world.usingComponentData(arrow, [ut.Core2D.Sprite2DRenderer, game.ArrowTag], function (renderer) {
                renderer.color = new ut.Core2D.Color(1, 1, 1, 0);
            });
            var diference = new Vector2(touchData.x - inputHelper.FirstTouchData.x, touchData.y - inputHelper.FirstTouchData.y);
            var normalized = diference.normalize();
            inputHelper.IsClickDown = false;
            ball.MoveDirection = normalized.multiplyScalar(-1);
            ball.Shoot = true;
            //GameSystem.CurrentGameMode = GameState.Playing;
            game.GameSystem.Play();
        };
        return PotencyInputSystem;
    }(ut.ComponentSystem));
    game.PotencyInputSystem = PotencyInputSystem;
})(game || (game = {}));
/**
 * const display = this.world.getConfigData(ut.Core2D.DisplayInfo);

            const refereceLength = display.frameHeight/2;

            this.world.forEach([ut.Entity, game.Ball, ut.Physics2D.Velocity2D, game.InputHelper], (entity, ball, velocity, inputHelper ) => {
                if(inputHelper.InputType == game.InputType.Direction){
                    return;
                }

                if(!ut.Core2D.Input.isTouchSupported()){
                    if( ut.Runtime.Input.getMouseButtonDown(0)){
                        let mousePos = ut.Core2D.Input.getInputPosition();
                        this.ProcessStartInput(mousePos, inputHelper);
                    }
                    else if(ut.Runtime.Input.getMouseButton(0)){
                        let mousePos = ut.Core2D.Input.getInputPosition();
                        this.ProcessOnPressed(mousePos, entity, velocity, ball, inputHelper,refereceLength);
                    }
                    else if (ut.Runtime.Input.getMouseButtonUp(0)) {
                        this.ProcessFinishInput(ball, inputHelper);
                    }
            }
            else {
                if (ut.Core2D.Input.touchCount() > 0) {
                    let touch: ut.Core2D.Touch = ut.Core2D.Input.getTouch(0);
                    if (touch.phase == ut.Core2D.TouchState.Began) {
                        //console.log("began: " + ut.Core2D.Input.touchCount());
                        this.ProcessStartInput(new Vector2(touch.x, touch.y), inputHelper);
                    }
                    else if (touch.phase == ut.Core2D.TouchState.Moved) {
                        this.ProcessOnPressed(new Vector2(touch.x, touch.y), entity, velocity, ball, inputHelper,refereceLength);
                        //console.log("moved: " + ut.Core2D.Input.touchCount());
                    }
                    else if (touch.phase == ut.Core2D.TouchState.Ended){
                        this.ProcessFinishInput(ball, inputHelper)
                    }
                }
            }
        
        });
 */
var ut;
(function (ut) {
    var EntityGroup = /** @class */ (function () {
        function EntityGroup() {
        }
        /**
         * @method
         * @desc Creates a new instance of the given entity group by name and returns all entities
         * @param {ut.World} world - The world to add to
         * @param {string} name - The fully qualified name of the entity group
         * @returns Flat list of all created entities
         */
        EntityGroup.instantiate = function (world, name) {
            var data = this.getEntityGroupData(name);
            if (data == undefined)
                throw "ut.EntityGroup.instantiate: No 'EntityGroup' was found with the name '" + name + "'";
            return data.load(world);
        };
        ;
        /**
         * @method
         * @desc Destroys all entities that were instantated with the given group name
         * @param {ut.World} world - The world to destroy from
         * @param {string} name - The fully qualified name of the entity group
         */
        EntityGroup.destroyAll = function (world, name) {
            var type = this.getEntityGroupData(name).Component;
            world.forEach([ut.Entity, type], function (entity, instance) {
                // @TODO This should REALLY not be necessary
                // We are protecting against duplicate calls to `destroyAllEntityGroups` within an iteration
                if (world.exists(entity)) {
                    world.destroyEntity(entity);
                }
            });
        };
        /**
         * @method
         * @desc Returns an entity group object by name
         * @param {string} name - Fully qualified group name
         */
        EntityGroup.getEntityGroupData = function (name) {
            var parts = name.split('.');
            if (parts.length < 2)
                throw "ut.Streaming.StreamingService.getEntityGroupData: name entry is invalid";
            var shiftedParts = parts.shift();
            var initialData = entities[shiftedParts];
            if (initialData == undefined)
                throw "ut.Streaming.StreamingService.getEntityGroupData: name entry is invalid";
            return parts.reduce(function (v, p) {
                return v[p];
            }, initialData);
        };
        return EntityGroup;
    }());
    ut.EntityGroup = EntityGroup;
})(ut || (ut = {}));
var ut;
(function (ut) {
    var EntityLookupCache = /** @class */ (function () {
        function EntityLookupCache() {
        }
        EntityLookupCache.getByName = function (world, name) {
            var entity;
            if (name in this._cache) {
                entity = this._cache[name];
                if (world.exists(entity))
                    return entity;
            }
            entity = world.getEntityByName(name);
            this._cache[name] = entity;
            return entity;
        };
        EntityLookupCache._cache = {};
        return EntityLookupCache;
    }());
    ut.EntityLookupCache = EntityLookupCache;
})(ut || (ut = {}));
//# sourceMappingURL=tsc-emit.js.map